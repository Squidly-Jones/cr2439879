/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 16, 2014, 10:38 AM
 * Assignment 3
 */
 
#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    //General Menu Format
    bool loop=true;
    do{
        //Display the selection
        cout<<"Type 1 Gaddis Ch. 4 Problem 1"<<endl;
        cout<<"Type 2 Gaddis Ch. 4 Problem 2"<<endl;
        cout<<"Type 3 Gaddis Ch. 4 Problem 3"<<endl;
        cout<<"Type 4 Gaddis Ch. 4 Problem 4"<<endl;
        cout<<"Type 5 Gaddis Ch. 4 Problem 5"<<endl;
        cout<<"Type 6 Gaddis Ch. 4 Problem 6"<<endl;
        cout<<"Type 7 Gaddis Ch. 4 Problem 7"<<endl;
        cout<<"Type 8 Gaddis Ch. 4 Problem 8"<<endl;
        cout<<"Type 9 Gaddis Ch. 4 Problem 9"<<endl;
        cout<<"Type 10 Gaddis Ch. 4 Problem 10"<<endl;
        cout<<"Type anything else to quit with no solutions."<<endl;
        //Read the choice
        int choice;
        cin>>choice;
        //Solve a problem that has been chosen.
        switch(choice){
            case 1:{
                        //Declare Variables
                        int num1, num2;
                        //Input numbers
                        cout<<"Input 2 numbers"<<endl;
                        cin>>num1>>num2;
                        //Find Min and Max
                        if (num1>num2) {
                        cout<<"Max = "<<num1<<" Min = "<<num2;
                        } else {
                        cout<<"Max = "<<num2<<" Min = "<<num1;
                }
                   break;
                }
            case 2:{
                        //Declare Variables
                        int number;
                        //Input number 1-10
                        cout<<"Input a number 1-10 to get the Roman Numeral"<<endl;
                        cin>>number;
                      switch (number) {
                        case 1:cout<<"Roman Numeral = I"<<endl;
                        break;
                        case 2:cout<<"Roman Numeral = II"<<endl;
                        break;
                        case 3:cout<<"Roman Numeral = III"<<endl;
                        break;
                        case 4:cout<<"Roman Numeral = IV"<<endl;
                        break;
                        case 5:cout<<"Roman Numeral = V"<<endl;
                        break;
                        case 6:cout<<"Roman Numeral = VI"<<endl;
                        break;
                        case 7:cout<<"Roman Numeral = VII"<<endl;
                        break;
                        case 8:cout<<"Roman Numeral = VIII"<<endl;
                        break;
                        case 9:cout<<"Roman Numeral = IX"<<endl;
                        break;
                        case 10:cout<<"Roman Numeral = X"<<endl;
                        break;
                      default:cout<<"You did not enter a number 1-10"<<endl;
                      }
                break;
                }
            case 3:{
                   //Declare Variables
                   int day, month, year;
                   //Input Date
                   cout<<"Input the date in question. Ex (dd mm yy)"<<endl;
                   cin>>day>>month>>year;
                   //Calculate Magic
                   if (year==day*month){
                       cout<<"This date is Magic!!!"<<endl;
                   } else {
                       cout<<"This date is not Magic."<<endl;
                   }
                break;
                }
            case 4:{
                    //Declare Variables
                    int area1,area2;
                    float width1,length1,width2,length2;
                    //Input Variables
                    cout<<"Input the 1st rectangles length then width."<<endl;
                    cin>>length1>>width1;
                    cout<<"Input the 2nd rectangles length then width."<<endl;
                    cin>>length2>>width2;
                    //Calculate area
                    area1=(length1*width1);
                    area2=(length2*width2);
                    //Tell which area is greater
                    if (area1==area2){
                        cout<<"The areas are equal"<<endl;
                    }else if (area1>area2){
                        cout<<"Rectangle 1's area is greater"<<endl;
                    }else{
                        cout<<"Rectangle 2's area is greater"<<endl;
                    }
                break;
                }
            case 5:{
                //Declare Variables
                float bmi,height,weight,squr;
                //Input Variable
                cout<<"What is your Weight? (lbs)"<<endl;
                cin>>weight;
                cout<<"What is your Height? (inchs)"<<endl;
                cin>>height;
                //Calculate BMI
                squr = (height*height);
                bmi = (weight*703)/squr;
                //Output BMI
                cout<<"Your BMI is = "<<bmi<<endl;
                break;
            }
            case 6:{
                //Declare Variables
                float mass,weight;
                //Input Mass
                cout<<"Input the objects mass"<<endl;
                cin>>mass;
                //Calculate and Output Weight
                weight = (mass*9.8);
                if (weight>1000){
                    cout<<"The object is too heavy!"<<endl;  
                }else if (weight<10){
                    cout<<"The object is too light!"<<endl;
                }else{
                    cout<<"The objects weight = "<<weight<<endl;
                }
                break;
            }
            case 7:{
                //Declare Variables
                int sec,sec1,sec2,sec3;
                //Input Seconds
                cout<<"Enter in the number of Seconds"<<endl;
                cin>>sec;
                //calculate
                if (sec>=86400){
                    sec3 = (sec/86400);
                    cout<<sec3<<" Days"<<endl;
                }else if (sec>=3600){
                    sec2 = (sec/3600);
                    cout<<sec2<<" Hours"<<endl;
                }else if (sec>=60){
                    sec1 = (sec/60);
                    cout<<sec1<<" Minutes"<<endl;
                }
                break;
            }
            case 8:{
                //Declare Variables
                int doll = 100,half,quart,dime,nik;
                int inhalf,inquart,indime,innik,pen;
                //Input Coins
                cout<<"Input the number of 50,25,10,5, and 1 cent coins in that order."<<endl;
                cout<<"Try to make the coins equal to 1 dollar"<<endl;
                cin>>inhalf>>inquart>>indime>>innik>>pen;
                //Calculate coin
                half = (inhalf*50);
                quart = (inquart*25);
                dime = (indime*10);
                nik = (innik*5);
                //Output win or loss
                if (doll==half+quart+dime+nik+pen){
                    cout<<"Congrats! You Win!"<<endl;
                }else{
                    cout<<"Sorry, Try Again"<<endl;
                }
                break;
            }
            case 9:{
                //Declare Variables
                float sale,price = 99;
                float dis1 = .20,dis2 = .30,dis3 = .40,dis4 = .50;
                //Input sales
                cout<<"How Many Units Were Sold?"<<endl;
                cin>>sale;
                //Calculate Discount
                if(sale>=100){
                    cout<<"Price = $"<<(sale*price)*dis4<<endl;
                }else if (sale<=99 && sale>=50){
                    cout<<"Price = $"<<(sale*price)*dis3<<endl;
                }else if (sale<=49 && sale>=20){
                    cout<<"Price = $"<<(sale*price)*dis2<<endl;
                }else{
                    cout<<"Price = $"<<(sale*price)*dis1<<endl;
                }
                break;
            }
            case 10:{
                //Declare Variables
                int books;
                //Input Books
                cout<<"How many books did you buy this month? (positive numbers only)"<<endl;
                cin>>books;
                //Output Points
                switch (books){
                        case 0:cout<<"You earned 0 points"<<endl;
                        break;
                        case 1:cout<<"You earned 5 points"<<endl;
                        break;
                        case 2:cout<<"You earned 15 points"<<endl;
                        break;
                        case 3:cout<<"You earned 30 points"<<endl;
                        break;
                        case 4:cout<<"You earned 60 points"<<endl;
                        break;
                        default:cout<<"You earned 60 points"<<endl;
                        break;
                }        
                break;
            }
                default:{
                        cout<<"Exit?"<<endl;
                        loop=false;
                        break;
                }
        };
    }while(loop);//Upper do-while
    return 0;
}

