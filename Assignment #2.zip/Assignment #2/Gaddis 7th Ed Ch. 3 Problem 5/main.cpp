/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 15, 2014, 8:30 AM
 * Box Office
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    string movname;
    float aprice = 6.00, cprice = 3.00;
    int adultT, childT;
    float perc = .20;
    int grossprf, netprof, paidamo;
    //Input Movie Name and Tickets sold
    cout<<"What is the movie title?"<<endl;
    cin>>movname;
    cout<<"How many Adult Tickets were sold?"<<endl;
    cin>>adultT;
    cout<<"How many Child Tickets were sold?"<<endl;
    cin>>childT;
    //Do the calculation
    grossprf = (adultT*aprice)+(childT*cprice);
    netprof = (grossprf*perc);
    paidamo = (grossprf-netprof);
    //Display Results
    cout<<"Movie Name: "<<movname<<endl;
    cout<<"Adults Tickets Sold: "<<adultT<<endl;
    cout<<"Child Tickets Sold: "<<childT<<endl;
    cout<<"Gross Box Office Profit: $"<<grossprf<<endl;
    cout<<"Net Box Office Profit: $"<<netprof<<endl;
    cout<<"Amount Paid to Distributor: $"<<paidamo<<endl;
    return 0;
}

