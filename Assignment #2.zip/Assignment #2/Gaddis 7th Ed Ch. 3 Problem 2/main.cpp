/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 14, 2014, 8:55 AM
 * Stadium Seating
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int classa, classb, classc;
    int aprice = 15, bprice = 12, cprice = 9;
    int profit = (classa*aprice)+(classb*bprice)+(classc*cprice);
    //Find number sold
    cout<<"How Many of each were sold?"<<endl;
    cout<<"Class A Seats"<<endl;
    cin>>classa;
    cout<<"Class B Seats"<<endl;
    cin>>classb;
    cout<<"Class C Seats"<<endl;
    cin>>classc;
    //Adjust
    cout<<setprecision(2)<<endl;
    cout<<fixed;
    cout<<showpoint;
    //Calculate profit
    cout<<"Profit from seat tickets = $";
    cout<<profit;
    return 0;
}

