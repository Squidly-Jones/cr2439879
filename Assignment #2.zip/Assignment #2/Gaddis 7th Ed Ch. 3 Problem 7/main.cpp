/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 15, 2014, 2:15 PM
 * How Many Calories
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float cooeatn, totcal;
    float calp10 = 4, calpers = 300;
    //Enter Cookies Eaten
    cout<<"How many cookies did you eat? "<<endl;
    cin>>cooeatn;
    //Calculate Total Calories
    totcal = (cooeatn/calp10)*calpers;
    //Display Calories
    cout<<"Total Calories = "<<totcal<<endl;
    return 0;
}

