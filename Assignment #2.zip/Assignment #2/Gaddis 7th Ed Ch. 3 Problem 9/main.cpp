/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 15, 2014, 3:02 PM
 * Auto Cost
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float loan,payment,insur,gas,oil,tires,mait;
    float monthly,annual;
    //Input Variables
    cout<<"Enter costs in the order they appear!"<<endl;
    cout<<"Input the cost for your car loan, payment, and insurance per month."<<endl;
    cin>>loan>>payment>>insur;
    cout<<"Input the cost for your car upkeep, gas, oil, and tires per month."<<endl;
    cin>>mait>>gas>>oil>>tires;
    //Output monthly and annual cost
    monthly = (loan+payment+insur+mait+gas+oil+tires);
    annual = (monthly*12);
    cout<<"Monthly Cost = $"<<monthly<<endl;
    cout<<"Annual Cost = $"<<annual<<endl;
    return 0;
}

