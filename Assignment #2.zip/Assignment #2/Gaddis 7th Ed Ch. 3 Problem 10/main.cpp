/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 15, 2014, 3:35 PM
 * Celsius to Fahrenheit
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float celsius,fare;
    //Input temp in Fahrenheit
    cout<<"What is the temp in Celsius?"<<endl;
    cin>>celsius;
    //Calculate
    fare = ((9*celsius)/5)+32;
    //Display Fahrenheit
    cout<<"The temp in Fahrenheit = "<<fare;
    return 0;
}

