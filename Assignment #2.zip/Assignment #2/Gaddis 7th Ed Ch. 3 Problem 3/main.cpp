/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 14, 2014, 9:19 AM
 * Test Average
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float t1, t2, t3, t4, t5;
    float sum;
    //Input Test Scores
    cout<<"Input each test score"<<endl;
    cout<<"Test 1"<<endl;
    cin>>t1;
    cout<<"Test 2"<<endl;
    cin>>t2;
    cout<<"Test 3"<<endl;
    cin>>t3;
    cout<<"Test 4"<<endl;
    cin>>t4;
    cout<<"Test 5"<<endl;
    cin>>t5;
    //Calculate Average
    sum = (t1+t2+t3+t4+t5)/5;
    cout<<"The average of the test scores is ";
    cout<<sum<<endl;
    return 0;
}

