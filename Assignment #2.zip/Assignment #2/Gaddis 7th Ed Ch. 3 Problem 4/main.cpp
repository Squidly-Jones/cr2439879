/* 
 * File:   main.cpp
 * Author: Cody Rudd 
 * Created on January 15, 2014, 7:20 AM
 * Average Rainfall
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float rain1, rain2, rain3;
    string month1, month2, month3;
    float avg;
    //Input months and rain fall
    cout<<"What three months do you want the average for?"<<endl;
    cin>>month1>>month2>>month3;
    cout<<"How many inches of rain fell each month?"<<endl;
    cin>>rain1>>rain2>>rain3;
    //Calculate Avg
    avg = (rain1+rain2+rain3)/3;
    //Display Average For 3 Months
    cout<<"The average rain for months "
            <<month1<<", "<<month2<<", and "<<month3<<" = "<<avg<<" inches"<<endl;
    return 0;
}

