/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 15, 2014, 9:57 AM
 * How Many Widgets
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float wid, pal, lbs = 9.2;
    //Ask pallet weight
    cout<<"How much does the pallet weigh in lbs?"<<endl;
    cin>>pal;
    //Calculate widget weight
    wid = (pal/lbs);
    //Display number of widgets
    cout<<"The number of widgets in this pallet = "<<wid<<endl;
    return 0;
}

