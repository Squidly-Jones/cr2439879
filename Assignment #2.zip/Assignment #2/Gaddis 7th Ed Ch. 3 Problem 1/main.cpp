/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 14, 2014, 8:08 AM
 * Find MPG
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int gal, mpft;
    //Input Data
    cout<<"How many gallons can the car hold?";
    cin>>gal;
    cout<<"How many miles can the car drive on a full tank?";
    cin>>mpft;
    //Find And Output MPG
    cout<<"Your car gets ";
    cout<<mpft/gal<<"mpg";
    return 0;
}

