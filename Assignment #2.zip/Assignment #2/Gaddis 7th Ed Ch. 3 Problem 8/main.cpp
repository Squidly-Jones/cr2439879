/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 15, 2014, 2:46 PM
 * How Much Insurance
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float replace, insur;
    //Ask Price
    cout<<"How much would it cost to replace this structure?"<<endl;
    cin>>replace;
    //Calculate and Display Insurance
    insur = (replace*.80);
    cout<<"Suggested Insurance = $"<<insur<<endl; 
    return 0;
}

