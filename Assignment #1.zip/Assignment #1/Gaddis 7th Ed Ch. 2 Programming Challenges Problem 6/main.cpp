/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 7, 2014, 6:19 PM
 * Annual Pay
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float Amount = 1700.0, Periods = 26, Annual  (Amount+Periods);
    //Display Annual Pay
    cout<<"$";
    cout<<Annual;
    cout<<" Annaual Pay"<<endl;
    return 0;
}

