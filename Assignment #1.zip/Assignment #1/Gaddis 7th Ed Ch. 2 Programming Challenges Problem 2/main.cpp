/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 7, 2014, 1:28 PM
 * Sales Prediction
 */

//System Libraries
#include <iostream>
using namespace std;

//Global constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    float comSale= 4600000, wesSale= (.062);
    cout<<"Company Sales = ";
    cout<<(comSale)<<endl;
    cout<<"West Coast Sales = ";
    cout<<(comSale*wesSale)<<endl;
    return 0;
}

