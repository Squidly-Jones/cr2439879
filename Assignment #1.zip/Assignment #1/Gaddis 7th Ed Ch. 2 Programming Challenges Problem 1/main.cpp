/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 7, 2014, 12:48 PM
 * Find the sum of two numbers
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int a = 62, b = 99;
    //Find and Display Sum
    cout<<"Sum of variables 62 + 99 = "<<(a+b)<<endl;
    return 0;
}

