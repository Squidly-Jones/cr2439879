/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 7, 2014, 12:48 PM
 * Find the sum of two numbers
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants
const int a=62,b=99;
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    cout<<"Sum of variables 62 + 99 = "<<(a+b)<<endl;
    return 0;
}

