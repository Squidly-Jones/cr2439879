/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 7, 2014, 3:41 PM
 * Average of Values
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int a = 28, b = 32, c = 37, d = 24, e = 33;
    //Calculate Sum
    cout<<(a+b+c+d+e); 
    cout<<" Sum"<<endl;
    return 0;
}

