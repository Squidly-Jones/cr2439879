/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 9, 2014, 9:59 AM
 * Gaddis 7th Ed Ch. 2 Problem 10
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int gal = 12, mil = 350;
    //Display Miles driven and Gallons
    cout<<gal<<" = Gallons the car holds."<<endl;
    cout<<mil<<" = Miles driven."<<endl;
    cout<<(mil/gal)<<" = MPG of car."<<endl;
    return 0;
}

