/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 7, 2014, 7:18 PM
 * Ocean Levels
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Display the change in 5 years
    cout<<1.5*4;
    cout<<" Millimeters in 5 years"<<endl;
    cout<<1.5*7;
    cout<<" Millimeters in 7 years"<<endl;
    cout<<1.5*10;
    cout<<" Millimeters in 10 years"<<endl;
    return 0;
}

