/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 7, 2014, 7:31 PM
 * Total Purchase
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float one= 12.95, two= 24.95, three= 6.95, four= 14.95, five= 3.95;
    float subto = (one+two+three+four+five);
    float saletax = (subto*.06);
    //Display Price of each
    cout<<"$"<<one<<" Product One"<<endl;
    cout<<"$"<<two<<" Product Two"<<endl;
    cout<<"$"<<three<<" Product Three"<<endl;
    cout<<"$"<<four<<" Product Four"<<endl;
    cout<<"$"<<five<<" Product Five"<<endl;
    //Display Subtotal
    cout<<"__________"<<endl;
    cout<<"$"<<subto<<" Subtotal"<<endl;
    //Display Sales Tax
    cout<<"* 6% Tax"<<endl;
    cout<<"__________"<<endl;
    cout<<"$"<<saletax<<" Sales Tax"<<endl;
    cout<<"__________"<<endl;
    //Display Total
    cout<<"$"<<(saletax+subto)<<" Total"<<endl;
    return 0;
}

