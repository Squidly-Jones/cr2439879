/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 7, 2014, 2:21 PM
 * Gaddis Ch.2 Programming Challenges Prob.3
 */
//System Libraries
#include <iostream>
using namespace std;

//Global Constants
int Sale=52;
float State=4e-2,Cont=2e-2;
//Function Prototypes

//Execution Begin Here
int main(int argc, char** argv) {
    cout<<"Total Sale Cost = "<<(Sale*State+Sale*Cont+Sale)<<endl;
    return 0;
}

