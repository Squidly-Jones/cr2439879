/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 9, 2014, 10:27 AM
 * Savitch 8th Ed Ch.1 Problem 10
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Char Variable
    char letter;
    //Input the Letter
    cout<<"What letter would you like to use"
            <<"to output capital?"<<endl;
    cin>>letter;
    //Output the Capital
    cout<<"  "<<letter<<" "<<letter<<" "<<letter<<endl;
    cout<<" "<<letter<<"    "<<letter<<endl;
    cout<<letter<<endl;
    cout<<letter<<endl;
    cout<<letter<<endl;
    cout<<letter<<endl;
    cout<<letter<<endl;
    cout<<" "<<letter<<"    "<<letter<<endl;
    cout<<"  "<<letter<<" "<<letter<<" "<<letter<<endl;
    return 0;
}
 
