/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 7, 2014, 8:04 PM
 * Total Purchases
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {

    return 0;
}

