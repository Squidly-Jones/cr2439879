/* 
 * File:   main.cpp
 * Author: Cody Rudd
 * Created on January 7, 2014, 2:40 PM
 * Restaurant Bill
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Display Variables
    float meal = 44.50, max = .0675, tip = .15;
    float imax = (meal*max), itip = (meal*tip);
    //Display Meal Cost
    cout<<"Meal Cost = ";
    cout<<"$";
    cout<<(meal)<<endl;
    //Display Tax
    cout<<"Sales Tax = ";
    cout<<"$";
    cout<<(meal*max)<<endl;
    //Display Tip
    cout<<"Tip = ";
    cout<<"$";
    cout<<(meal*tip)<<endl;
    //Display Total
    cout<<"Total Cost = ";
    cout<<"$";
    cout<<(meal+imax+itip)<<endl;
    return 0;
}

